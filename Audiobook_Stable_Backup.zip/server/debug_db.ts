
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    console.log('--- USERS ---');
    const users = await prisma.user.findMany();
    console.table(users.map(u => ({ id: u.id, email: u.email, name: u.name })));

    console.log('\n--- BOOKS ---');
    const books = await prisma.book.findMany();
    console.table(books.map(b => ({ id: b.id, title: b.title, userId: b.userId })));
}

main()
    .catch(e => console.error(e))
    .finally(async () => await prisma.$disconnect());
