import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
    const books = await prisma.book.findMany({
        select: { id: true, title: true, coverImagePath: true, coverUrl: true }
    });
    console.log(JSON.stringify(books, null, 2));
}

main().finally(() => prisma.$disconnect());
