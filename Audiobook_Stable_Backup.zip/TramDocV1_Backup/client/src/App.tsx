import { useState, useEffect } from 'react';
import axios from 'axios';
import BookReader from './components/BookReader';

interface Book {
  id: number;
  title: string;
  author: string;
  coverImageUrl?: string;
  createdAt: string;
}

function App() {
  const [books, setBooks] = useState<Book[]>([]);
  const [uploading, setUploading] = useState(false);
  const [selectedBookId, setSelectedBookId] = useState<number | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ bookId: number, title: string } | null>(null);

  const loadBooks = async () => {
    try {
      const res = await axios.get('http://localhost:3000/api/books');
      setBooks(res.data);
    } catch (error) {
      console.error('Error loading books:', error);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.epub')) {
      alert('Please upload an EPUB file');
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('book', file);

    try {
      const res = await axios.post('http://localhost:3000/api/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      alert(`Book processed successfully! ID: ${res.data.bookId}`);
      loadBooks();
    } catch (error: any) {
      alert(`Error: ${error.response?.data?.error || error.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteBook = (bookId: number, bookTitle: string) => {
    setDeleteConfirm({ bookId, title: bookTitle });
  };

  const confirmDelete = async () => {
    if (!deleteConfirm) return;

    try {
      await axios.delete(`http://localhost:3000/api/books/${deleteConfirm.bookId}`);
      alert(`Book "${deleteConfirm.title}" deleted successfully!`);
      loadBooks();
    } catch (error: any) {
      alert(`Error deleting book: ${error.response?.data?.error || error.message}`);
    } finally {
      setDeleteConfirm(null);
    }
  };

  useEffect(() => {
    loadBooks();
  }, []);

  if (selectedBookId !== null) {
    return <BookReader bookId={selectedBookId} onClose={() => setSelectedBookId(null)} />;
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans selection:bg-emerald-500/30">
      <div className="container mx-auto px-4 py-8">
        {/* New Header */}
        <header className="flex flex-col md:flex-row items-center justify-between mb-12 py-6 border-b border-slate-800/50">
          <div className="flex items-center gap-8 mb-8 md:mb-0">
            <div className="relative group w-48 h-48 md:w-64 md:h-64 rounded-full overflow-hidden shadow-2xl ring-4 ring-slate-800 bg-slate-900">
              <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-teal-600 rounded-full blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
              <img
                src="/logo.png"
                alt="Trạm Đọc Logo"
                className="relative w-full h-full object-cover transform scale-125 transition-transform duration-500 hover:scale-135 hover:rotate-3"
              />
            </div>
            <div>
              <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent drop-shadow-lg">
                Trạm Đọc
              </h1>
            </div>
          </div>

          {/* Compact Upload Button */}
          <label className="group relative cursor-pointer">
            <input
              type="file"
              accept=".epub"
              onChange={handleFileUpload}
              disabled={uploading}
              className="hidden"
            />
            <div className="flex items-center gap-3 bg-slate-800 hover:bg-slate-700 text-emerald-400 px-6 py-3 rounded-full border border-slate-700 hover:border-emerald-500/50 transition-all duration-300 shadow-lg hover:shadow-emerald-500/10">
              <span className="text-xl group-hover:-translate-y-0.5 transition-transform duration-300">
                {uploading ? '⏳' : '📤'}
              </span>
              <span className="font-semibold text-sm uppercase tracking-wider">
                {uploading ? 'Processing...' : 'Upload Book'}
              </span>
            </div>
          </label>
        </header>

        {/* Books Library */}
        <main>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <span className="text-emerald-500">📚</span> Your Library
            </h2>
            <span className="text-slate-500 text-sm font-medium">
              {books.length} {books.length === 1 ? 'Book' : 'Books'}
            </span>
          </div>

          {books.length === 0 ? (
            <div className="text-center py-20 bg-slate-800/30 rounded-3xl border border-slate-700/50 border-dashed">
              <div className="text-6xl mb-6 opacity-50">📖</div>
              <p className="text-slate-300 text-xl font-medium mb-2">Your library is empty</p>
              <p className="text-slate-500">Upload your first EPUB file to get started!</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-6">
              {books.map((book) => (
                <div
                  key={book.id}
                  onClick={() => setSelectedBookId(book.id)}
                  className="group relative bg-slate-800/50 hover:bg-slate-800 rounded-2xl overflow-hidden border border-slate-700/50 hover:border-emerald-500/30 transition-all duration-300 cursor-pointer hover:-translate-y-2 hover:shadow-2xl hover:shadow-emerald-500/10 flex flex-col h-full"
                  title={`${book.title} by ${book.author}`}
                >
                  {/* Cover Image Container */}
                  <div className="aspect-[2/3] w-full bg-slate-900 relative overflow-hidden">
                    {book.coverImageUrl ? (
                      <img
                        src={`http://localhost:3000${book.coverImageUrl}`}
                        alt={book.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-800 to-slate-700">
                        <span className="text-4xl opacity-50">📘</span>
                      </div>
                    )}

                    {/* Hover Overlay */}
                    <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-sm">
                      <div className="bg-emerald-500 text-white p-4 rounded-full shadow-lg transform scale-90 group-hover:scale-100 transition-transform duration-300">
                        <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
                          <path d="M8 5v14l11-7z" />
                        </svg>
                      </div>
                    </div>

                    {/* Delete Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteBook(book.id, book.title);
                      }}
                      className="absolute top-2 right-2 p-2 bg-slate-900/80 hover:bg-red-500 text-slate-400 hover:text-white rounded-full opacity-0 group-hover:opacity-100 transition-all duration-200 backdrop-blur-md border border-white/10 z-10"
                      title="Delete book"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 rounded-2xl p-8 max-w-md w-full border border-slate-700 shadow-2xl">
            <h3 className="text-2xl font-bold text-white mb-4">Delete Book?</h3>
            <p className="text-slate-400 mb-2">
              Are you sure you want to delete:
            </p>
            <p className="text-emerald-400 font-semibold mb-6">
              "{deleteConfirm.title}"
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-medium py-3 px-6 rounded-xl transition-all border border-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="flex-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-medium py-3 px-6 rounded-xl transition-all border border-red-500/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
