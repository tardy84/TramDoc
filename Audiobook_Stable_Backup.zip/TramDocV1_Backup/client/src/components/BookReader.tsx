import { useEffect, useState, useCallback, useRef } from 'react';
import axios from 'axios';
import { getGlobalAudio, setGlobalAudio } from '../services/audioPlayer';

// Lifecycle Debug
// eslint-disable-next-line
// let globalAudio: HTMLAudioElement | null = null; // MOVED TO SINGLETON SERVICE


interface Segment {
    id: number;
    content: string;
    role: string;
    orderIndex: number;
}

interface Chapter {
    id: number;
    title: string;
    orderIndex: number;
    segments: Segment[];
    isTableOfContents?: boolean;
}

interface Book {
    id: number;
    title: string;
    author?: string;
    coverImageUrl?: string;
    chapters: Chapter[];
}

interface Bookmark {
    id: number;
    bookId: number;
    chapterId: number;
    segmentId: number;
    previewText: string;
    note?: string;
    createdAt: string;
    chapter: {
        title: string;
        orderIndex: number;
    };
}

interface BookReaderProps {
    bookId: number;
    onClose: () => void;
}


export default function BookReader({ bookId, onClose }: BookReaderProps) {
    const [book, setBook] = useState<Book | null>(null);
    const [chapters, setChapters] = useState<Chapter[]>([]);
    const [currentChapterIndex, setCurrentChapterIndex] = useState(0);

    // Enhanced Close Handler
    const handleClose = useCallback(() => {
        console.log('[BookReader] Closing...');

        // Stop Global Audio
        const currentGlobal = getGlobalAudio();
        if (currentGlobal) {
            currentGlobal.pause();
            setGlobalAudio(null);
        }

        // Stop Browser TTS
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }

        onClose();
    }, [onClose]);
    const [audioFiles, setAudioFiles] = useState<string[]>([]);
    const [currentSegmentIndex, setCurrentSegmentIndex] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [loading, setLoading] = useState(true);
    const [generating, setGenerating] = useState(false);
    // const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null); // Unused
    const [showToc, setShowToc] = useState(false); // Toggle for Table of Contents panel
    const [isRestored, setIsRestored] = useState(false); // Track if progress has been restored from localStorage

    // Missing State Definitions
    const [playbackSpeed, setPlaybackSpeed] = useState(1);
    const [browserTTSMode, setBrowserTTSMode] = useState(false);
    const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
    const currentChapter = chapters[currentChapterIndex];

    // Lifecycle Debug
    useEffect(() => {
        return () => {
        };
    }, [bookId]);

    // Toast State
    const [toast, setToast] = useState<{ message: string; type: 'info' | 'error' | 'success' } | null>(null);

    const showToast = useCallback((message: string, type: 'info' | 'error' | 'success' = 'info') => {
        setToast({ message, type });
        setTimeout(() => setToast(null), 3000);
    }, []);

    // Auto-save progress when chapter or segment changes
    useEffect(() => {
        // Only save after initial load AND after restore is complete
        if (!loading && isRestored) {
            // Inline save to avoid circular dependency
            const progress = {
                bookId,
                chapterIndex: currentChapterIndex,
                segmentIndex: currentSegmentIndex,
                timestamp: Date.now()
            };
            localStorage.setItem(`audiobook_progress_${bookId}`, JSON.stringify(progress));
        }
    }, [bookId, currentChapterIndex, currentSegmentIndex, loading, isRestored]);

    // Fetch book and chapters
    useEffect(() => {
        const fetchBook = async () => {
            try {
                const res = await axios.get(`http://localhost:3000/api/books`);
                const foundBook = res.data.find((b: Book) => b.id === bookId);

                if (foundBook) {
                    setBook(foundBook);
                    const sortedChapters = foundBook.chapters.sort((a: Chapter, b: Chapter) => a.orderIndex - b.orderIndex);
                    setChapters(sortedChapters);

                    // Restore reading progress from localStorage
                    const savedProgress = localStorage.getItem(`audiobook_progress_${bookId}`);

                    if (savedProgress) {
                        try {
                            const { chapterIndex, segmentIndex } = JSON.parse(savedProgress);

                            // Validate indices are within bounds
                            const validCh = Math.max(0, chapterIndex);
                            if (validCh < sortedChapters.length) {
                                // Calculate valid segment index
                                let validSeg = 0;
                                if (sortedChapters[validCh]?.segments) {
                                    validSeg = Math.min(Math.max(0, segmentIndex), sortedChapters[validCh].segments.length - 1);
                                }

                                // If changing chapter, use pending ref to survive the useEffect reset
                                if (validCh !== currentChapterIndex) {
                                    pendingSegmentRef.current = validSeg;
                                    setCurrentChapterIndex(validCh);
                                } else {
                                    // Same chapter (likely 0), manual set since effect won't run
                                    setCurrentSegmentIndex(validSeg);
                                }
                            }
                        } catch (e) {
                            console.error("[BookReader] Failed to parse saved progress", e);
                        }
                    }
                    setIsRestored(true); // Enable auto-save logic regardless of whether progress was found or parsed
                }
            } catch (error) {
                console.error('Error fetching book:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchBook();
    }, [bookId]);

    // Refs to track active requests and chapter state
    const activeChapterIdRef = useRef<number | null>(null);
    const abortControllerRef = useRef<AbortController | null>(null);
    const audioRef = useRef<HTMLAudioElement | null>(null); // Ref for synchronous audio control
    // Refs for auto-scroll
    const segmentRefs = useRef<(HTMLParagraphElement | null)[]>([]);
    const pendingSegmentRef = useRef<number | null>(null); // Track pending segment for bookmark navigation

    // Scroll to active segment
    useEffect(() => {
        if (isPlaying && segmentRefs.current[currentSegmentIndex]) {
            segmentRefs.current[currentSegmentIndex]?.scrollIntoView({
                behavior: 'smooth',
                block: 'center',
            });
        }
    }, [currentSegmentIndex, isPlaying]);

    // Update active chapter ref when chapter changes and cleanup
    useEffect(() => {
        if (chapters[currentChapterIndex]) {
            activeChapterIdRef.current = chapters[currentChapterIndex].id;
            // Reset segment refs when chapter changes
            segmentRefs.current = [];

            // Restore pending segment (from bookmark/restore) or reset to 0
            if (pendingSegmentRef.current !== null) {
                setCurrentSegmentIndex(pendingSegmentRef.current);
                pendingSegmentRef.current = null;
            } else {
                // Ensure we start at the beginning of the chapter (fixes ToC navigation)
                setCurrentSegmentIndex(0);
            }

            // Clear stale audio files to force regeneration/refetch with correct extension
            setAudioFiles([]);
            setBrowserTTSMode(false); // Reset fallback mode too
        }

        // Abort previous request when chapter changes
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            abortControllerRef.current = null;
        }

        // Stop current audio immediately using Global
        // Cleanup only when component unmounts or chapter changes
        const currentGlobal = getGlobalAudio();
        if (currentGlobal) {
            console.log('[BookReader] Cleanup: Stopping global audio');
            currentGlobal.pause();
            currentGlobal.onended = null; // Prevent callbacks
            currentGlobal.onerror = null;
            setGlobalAudio(null);
        }
        audioRef.current = null;

        // Stop Browser TTS too
        window.speechSynthesis.cancel();

        // Reset generating state if we moved away
        setGenerating(false);

    }, [currentChapterIndex, chapters]);

    // Speed Control
    const toggleSpeed = () => {
        const speeds = [1, 1.25, 1.5, 2, 0.75];
        const nextSpeed = speeds[(speeds.indexOf(playbackSpeed) + 1) % speeds.length];
        setPlaybackSpeed(nextSpeed);

        // Apply to current audio
        if (audioRef.current) {
            audioRef.current.playbackRate = nextSpeed;
        }
        // Browser TTS picks this up on next segment, or we can try to update live if possible (often requires restart)
        if (window.speechSynthesis.speaking) {
            // For Browser TTS, dynamic speed change often requires restarting the utterance. 
            // For now, we just set state so next segment uses it.
            // To force update: 
            // window.speechSynthesis.cancel(); 
            // playBrowserTTS(currentSegmentIndex); 
            // But that might be jarring. Let's stick to state update for now.
        }
    };

    // Update audio rate when speed changes (if audio exists)
    useEffect(() => {
        if (audioRef.current) {
            audioRef.current.playbackRate = playbackSpeed;
        }
    }, [playbackSpeed]);

    // Navigation functions (Restored)
    const prevChapter = () => {
        if (currentChapterIndex > 0) {
            setCurrentChapterIndex(prev => prev - 1);
            setCurrentSegmentIndex(0);
        }
    };

    const nextChapter = useCallback(() => {
        if (currentChapterIndex < chapters.length - 1) {
            setCurrentChapterIndex(prev => prev + 1);
            setCurrentSegmentIndex(0);
        }
    }, [currentChapterIndex, chapters.length]);


    // Browser TTS Logic - Updated to use playbackSpeed
    // Browser TTS Logic - Updated to use playbackSpeed
    const playBrowserTTS = useCallback((index: number) => {
        if (!activeChapterIdRef.current || !chapters[currentChapterIndex]) return;
        if (activeChapterIdRef.current !== chapters[currentChapterIndex].id) return;
        if (!chapters[currentChapterIndex]?.segments[index]) return;

        window.speechSynthesis.cancel();

        const segment = chapters[currentChapterIndex].segments[index];
        const utterance = new SpeechSynthesisUtterance(segment.content);
        utterance.lang = 'vi-VN';
        utterance.rate = playbackSpeed;

        // Try to find a good voice
        const voices = window.speechSynthesis.getVoices();
        const googleVoice = voices.find(v => v.name.includes('Google') && v.lang.includes('vi'));
        if (googleVoice) utterance.voice = googleVoice;

        utterance.onstart = () => {
            setIsPlaying(true);
            setCurrentSegmentIndex(index);
        };

        utterance.onend = () => {
            if (!activeChapterIdRef.current) return;
            if (index < chapters[currentChapterIndex].segments.length - 1) {
                playBrowserTTS(index + 1);
            } else {
                if (currentChapterIndex < chapters.length - 1) {
                    nextChapter();
                } else {
                    setIsPlaying(false);
                }
            }
        };

        utterance.onerror = (e) => {
            console.error('[BrowserTTS] Error:', e);
            if (e.error !== 'interrupted') {
                setIsPlaying(false);
            }
        };

        window.speechSynthesis.speak(utterance);
        utteranceRef.current = utterance;
    }, [chapters, currentChapterIndex, nextChapter, playbackSpeed]);

    // Audio Playback & Generation
    const playSegment = (index: number, filesOverride?: string[]) => {
        // UPDATE UI IMMEDIATELY
        setCurrentSegmentIndex(index);
        const intendedChapterId = chapters[currentChapterIndex]?.id;
        if (activeChapterIdRef.current !== intendedChapterId) return;

        const files = filesOverride || audioFiles;
        if (!files || files.length === 0 || index < 0 || index >= files.length) return;

        const url = `http://localhost:3000${files[index]}`;
        const currentGlobal = getGlobalAudio();

        if (currentGlobal) {
            const currentSrc = currentGlobal.src.split('?')[0];
            const newSrc = url.split('?')[0];
            if (currentSrc === newSrc) {
                if (currentGlobal.paused) currentGlobal.play().catch(console.error);
                audioRef.current = currentGlobal;
                setIsPlaying(true);
                return;
            }
            currentGlobal.pause();
            setGlobalAudio(null);
        }

        const audio = new Audio(url);
        audio.playbackRate = playbackSpeed;
        setGlobalAudio(audio);
        audioRef.current = audio;
        (window as any).currentAudio = audio;

        audio.onerror = (e) => {
            console.error(`[BookReader] Audio load error:`, e);
            showToast(`Lỗi tải file`, "error");
            setBrowserTTSMode(true);
            playBrowserTTS(index);
        };

        audio.onended = () => {
            if (activeChapterIdRef.current !== intendedChapterId) return;
            if (index + 1 < files.length) {
                playSegment(index + 1, files);
            } else {
                if (currentChapterIndex < chapters.length - 1) {
                    nextChapter();
                } else {
                    setIsPlaying(false);
                }
            }
        };

        audio.play().catch(error => {
            if (error.name === 'AbortError') return;
            if (activeChapterIdRef.current !== intendedChapterId) return;
            if (error.name === 'NotAllowedError') {
                showToast("Paused", "info");
                setIsPlaying(false);
                return;
            }
            // console.error("Play error:", error);
            setBrowserTTSMode(true);
            playBrowserTTS(index);
        });

        setIsPlaying(true);
    };

    const generateAudio = useCallback(async (startFromIndex?: number) => {
        if (chapters.length === 0) return;
        const chapter = chapters[currentChapterIndex];
        activeChapterIdRef.current = chapter.id;

        if (abortControllerRef.current) abortControllerRef.current.abort();
        const controller = new AbortController();
        abortControllerRef.current = controller;

        setGenerating(true);
        setBrowserTTSMode(false);
        try {
            const res = await axios.post(
                `http://localhost:3000/api/books/${bookId}/chapters/${chapter.id}/tts`,
                { voice: 'vi-VN-Standard-A' },
                { signal: controller.signal }
            );

            if (activeChapterIdRef.current !== chapter.id) return;

            const newAudioFiles = res.data.audioFiles;
            setAudioFiles(newAudioFiles);

            const targetIndex = typeof startFromIndex === 'number' ? startFromIndex : currentSegmentIndex;
            const validIndex = Math.min(targetIndex, newAudioFiles.length - 1);
            playSegment(validIndex, newAudioFiles);
        } catch (error: any) {
            if (axios.isCancel(error)) return;
            // console.error('[BookReader] Generation error:', error);

            if (error.response?.status === 429 || error.response?.status === 404 || error.response?.status >= 500) {
                showToast("Server Busy, Switching to Browser TTS", "info");
                setBrowserTTSMode(true);
                setGenerating(false);
                playBrowserTTS(typeof startFromIndex === 'number' ? startFromIndex : currentSegmentIndex);
                return;
            }
            showToast(`Generating Error: ${error.message}`, 'error');
        } finally {
            if (activeChapterIdRef.current === chapter.id) {
                setGenerating(false);
                abortControllerRef.current = null;
            }
        }
    }, [bookId, chapters, currentChapterIndex, currentSegmentIndex]);

    const togglePlayPause = () => {
        if (browserTTSMode) {
            if (window.speechSynthesis.speaking) {
                window.speechSynthesis.paused ? window.speechSynthesis.resume() : window.speechSynthesis.pause();
                setIsPlaying(!window.speechSynthesis.paused);
            } else {
                playBrowserTTS(currentSegmentIndex);
            }
            return;
        }

        if (audioFiles.length === 0) {
            generateAudio(currentSegmentIndex);
            return;
        }

        if (isPlaying && audioRef.current) {
            audioRef.current.pause();
            setIsPlaying(false);
        } else if (audioRef.current && !isPlaying) {
            audioRef.current.play().catch(() => playSegment(currentSegmentIndex));
            setIsPlaying(true);
        } else {
            playSegment(currentSegmentIndex);
        }
    };

    // Bookmark State
    const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
    const [showBookmarks, setShowBookmarks] = useState(false);

    useEffect(() => {
        const fetchBookmarks = async () => {
            try {
                const res = await axios.get(`http://localhost:3000/api/books/${bookId}/bookmarks`);
                setBookmarks(res.data);
            } catch (e) { console.error(e); }
        };
        fetchBookmarks();
    }, [bookId]);

    const toggleBookmark = async (e: React.MouseEvent, segment: Segment, chapterId: number) => {
        e.stopPropagation();
        const existing = bookmarks.find(b => b.chapterId === chapterId && b.segmentId === segment.id);
        if (existing) {
            try {
                await axios.delete(`http://localhost:3000/api/bookmarks/${existing.id}`);
                setBookmarks(prev => prev.filter(b => b.id !== existing.id));
            } catch (e) { console.error(e); }
        } else {
            try {
                const res = await axios.post('http://localhost:3000/api/bookmarks', {
                    bookId, chapterId, segmentId: segment.id,
                    previewText: segment.content.substring(0, 100), note: ''
                });
                setBookmarks(prev => [res.data, ...prev]);
            } catch (e) { console.error(e); }
        }
    };

    if (loading) {
        return (
            <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50">
                <div className="text-white text-2xl">Loading book...</div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 z-50 overflow-hidden">
            {/* ... Toast ... */}
            {toast && (
                <div className={`fixed top-24 left-1/2 transform -translate-x-1/2 px-6 py-3 rounded-full shadow-2xl z-[60] flex items-center gap-3 transition-all animate-fade-in-down ${toast.type === 'error' ? 'bg-red-500/90 text-white' :
                    toast.type === 'success' ? 'bg-green-500/90 text-white' :
                        'bg-blue-500/90 text-white'
                    }`}>
                    <span>{toast.type === 'error' ? '⚠️' : toast.type === 'success' ? '✅' : 'ℹ️'}</span>
                    <span className="font-medium">{toast.message}</span>
                </div>
            )}

            {/* Header */}
            <div className="bg-black/30 backdrop-blur-md border-b border-white/10 p-4 relative z-50">
                <div className="container mx-auto flex items-center justify-between">
                    {/* Clean Header - Removed Chapter Text */}
                    <h1 className="text-xl font-bold text-white/50 truncate max-w-[50%]">
                        {/* Empty or minimal title if needed. User asked to remove 'Chapter 8' line. Keeping it empty or just 'Audiobook' is cleaner. 
                             Let's keep book title or just empty space?
                             "Bỏ cái dòng Chapter 8 đi" impliest removal. 
                             I'll just put the controls buttons on right.
                         */}
                    </h1>

                    <div className="flex gap-3">
                        <button
                            onClick={() => {
                                setShowBookmarks(!showBookmarks);
                                setShowToc(false);
                            }}
                            className={`p-2 rounded-lg border transition-all ${showBookmarks
                                ? 'bg-yellow-500/30 text-yellow-200 border-yellow-400/50'
                                : 'bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-200 border-yellow-400/30'
                                }`}
                            title="Bookmarks"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                            </svg>
                        </button>
                        <button
                            onClick={() => {
                                setShowToc(!showToc);
                                setShowBookmarks(false);
                            }}
                            className={`p-2 rounded-lg border transition-all ${showToc
                                ? 'bg-blue-500/30 text-blue-200 border-blue-400/50'
                                : 'bg-blue-500/20 hover:bg-blue-500/30 text-blue-200 border-blue-400/30'
                                }`}
                            title="Table of Contents"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                            </svg>
                        </button>
                        <button
                            onClick={handleClose}
                            className="p-2 bg-red-500/20 hover:bg-red-500/30 text-red-200 rounded-lg border border-red-400/30 transition-all"
                            title="Close"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            {/* Main Content Area */}
            <div className="container mx-auto px-4 py-8 h-[calc(100vh-200px)] overflow-y-auto">
                {currentChapter && (
                    <>
                        <h2 className="text-3xl font-bold text-white mb-6">
                            {currentChapter.title}
                        </h2>
                        {/* ... (Existing Content Logic) ... */}
                        {currentChapter.orderIndex === 0 && book?.coverImageUrl ? (
                            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20 flex items-center justify-center">
                                <img
                                    src={`http://localhost:3000${book.coverImageUrl}`}
                                    alt={`${book.title} cover`}
                                    className="max-w-md max-h-[70vh] object-contain rounded-lg shadow-2xl"
                                />
                            </div>
                        ) : (
                            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                                {currentChapter.segments?.map((segment, index) => {
                                    const isBookmarked = bookmarks.some(b => b.chapterId === currentChapter.id && b.segmentId === segment.id);
                                    return (
                                        <div
                                            key={segment.id}
                                            ref={el => { segmentRefs.current[index] = el; }}
                                            onClick={() => {
                                                if (audioFiles.length > 0) {
                                                    playSegment(index);
                                                } else {
                                                    if (generating) {
                                                        showToast('Đang tạo âm thanh, vui lòng đợi...', 'info');
                                                    } else {
                                                        showToast('Đang tự động tạo audio cho chương này...', 'success');
                                                        generateAudio(index);
                                                    }
                                                }
                                            }}
                                            className={`group relative mb-4 p-2 rounded-lg transition-all cursor-pointer ${index === currentSegmentIndex && isPlaying
                                                ? 'bg-yellow-500/20 ring-1 ring-yellow-500/50'
                                                : 'hover:bg-white/5'
                                                }`}
                                        >
                                            <button
                                                onClick={(e) => toggleBookmark(e, segment, currentChapter.id)}
                                                className={`absolute -left-8 top-2 p-1.5 rounded-full transition-all ${isBookmarked
                                                    ? 'opacity-100 text-yellow-400 hover:text-yellow-300'
                                                    : 'opacity-0 group-hover:opacity-50 hover:!opacity-100 text-gray-500 hover:text-yellow-400'
                                                    }`}
                                                title={isBookmarked ? "Remove Bookmark" : "Add Bookmark"}
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill={isBookmarked ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                                </svg>
                                            </button>

                                            <p className={`text-lg leading-relaxed ${index === currentSegmentIndex && isPlaying
                                                ? 'text-yellow-200'
                                                : 'text-gray-200'
                                                }`}>
                                                {segment.content}
                                            </p>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </>
                )}
            </div>

            {/* Compact Controls */}
            <div className="fixed bottom-0 left-0 right-0 bg-black/50 backdrop-blur-md border-t border-white/10 p-6 z-40">
                <div className="container mx-auto flex items-center justify-center gap-6">

                    {/* Previous Chapter */}
                    <button
                        onClick={prevChapter}
                        disabled={currentChapterIndex === 0}
                        className="p-4 bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed text-white rounded-full transition-all shadow-lg backdrop-blur-sm"
                        title="Previous Chapter"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
                        </svg>
                    </button>

                    {/* Audio Controls */}
                    {audioFiles.length === 0 ? (
                        <button
                            onClick={() => generateAudio()}
                            disabled={generating}
                            className="p-4 bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 disabled:from-gray-500 disabled:to-gray-600 text-white font-bold rounded-full transition-all shadow-lg transform hover:scale-105 disabled:scale-100 aspect-square flex items-center justify-center w-16 h-16"
                            title={generating ? "Generating Audio..." : "Generate & Play"}
                        >
                            {generating ? (
                                <svg className="animate-spin h-8 w-8 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                            ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            )}
                        </button>
                    ) : (
                        <button
                            onClick={togglePlayPause}
                            className="relative z-10 p-5 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-bold rounded-full transition-all shadow-lg transform hover:scale-105 active:scale-95 flex items-center justify-center w-16 h-16"
                            title={isPlaying ? "Pause" : "Play"}
                        >
                            {isPlaying ? (
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            )}
                        </button>
                    )}

                    {/* Next Chapter */}
                    <button
                        onClick={nextChapter}
                        disabled={currentChapterIndex === chapters.length - 1}
                        className="p-4 bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed text-white rounded-full transition-all shadow-lg backdrop-blur-sm"
                        title="Next Chapter"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
                        </svg>
                    </button>

                    {/* Speed Control */}
                    <button
                        onClick={toggleSpeed}
                        className="p-3 ml-4 bg-white/10 hover:bg-white/20 text-white/80 hover:text-white rounded-lg transition-all text-sm font-mono font-bold border border-white/10 w-12 text-center"
                        title={`Playback Speed: ${playbackSpeed}x. Click to change.`}
                    >
                        {playbackSpeed}x
                    </button>

                </div>
            </div>

            {/* Table of Contents Panel - Floating */}
            {showToc && (
                <div className="fixed top-20 right-4 w-80 max-h-[calc(100vh-120px)] bg-black/90 backdrop-blur-xl border border-white/20 rounded-2xl shadow-2xl overflow-hidden z-50">
                    <div className="p-4 bg-white/10 border-b border-white/20 flex justify-between items-center">
                        <h3 className="text-xl font-bold text-white">📑 Mục Lục</h3>
                        <button onClick={() => setShowToc(false)} className="text-gray-400 hover:text-white">✕</button>
                    </div>
                    <div className="overflow-y-auto max-h-[calc(100vh-200px)]">
                        {chapters.map((chapter, index) => {
                            if (chapter.orderIndex === 0 || chapter.isTableOfContents) return null;

                            const isCurrent = index === currentChapterIndex;
                            const displayNumber = index;

                            return (
                                <button
                                    key={chapter.id}
                                    onClick={() => {
                                        setCurrentChapterIndex(index);
                                        setShowToc(false);
                                    }}
                                    className={`w-full text-left px-4 py-3 transition-all border-b border-white/5 ${isCurrent
                                        ? 'bg-blue-500/30 text-white font-semibold'
                                        : 'text-gray-300 hover:bg-white/10 hover:text-white'
                                        }`}
                                >
                                    <div className="flex items-start gap-3">
                                        <span className="text-blue-400 font-mono text-sm mt-0.5">
                                            {displayNumber.toString().padStart(2, '0')}
                                        </span>
                                        <span className="flex-1 line-clamp-2">
                                            {chapter.title}
                                        </span>
                                        {isCurrent && <span className="text-blue-400">►</span>}
                                    </div>
                                </button>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* Bookmarks Panel - Floating */}
            {showBookmarks && (
                <div className="fixed top-20 right-4 w-96 max-h-[calc(100vh-120px)] bg-black/90 backdrop-blur-xl border border-yellow-500/20 rounded-2xl shadow-2xl overflow-hidden z-50">
                    <div className="p-4 bg-yellow-900/20 border-b border-yellow-500/20 flex justify-between items-center">
                        <h3 className="text-xl font-bold text-yellow-500">🔖 Saved Bookmarks</h3>
                        <button onClick={() => setShowBookmarks(false)} className="text-gray-400 hover:text-white">✕</button>
                    </div>
                    <div className="overflow-y-auto max-h-[calc(100vh-200px)] p-4 space-y-3">
                        {bookmarks.length === 0 ? (
                            <div className="text-center text-gray-500 py-8">
                                <p>No bookmarks yet.</p>
                                <p className="text-sm">Click the  icon next to any paragraph to save it.</p>
                            </div>
                        ) : (
                            bookmarks.map(bookmark => (
                                <div key={bookmark.id} className="bg-white/5 rounded-xl p-3 border border-white/5 hover:border-yellow-500/30 transition-all group">
                                    <div
                                        onClick={() => {
                                            // Find exact indices
                                            const chapterIdx = chapters.findIndex(c => c.id === bookmark.chapterId);
                                            if (chapterIdx !== -1) {
                                                const chapter = chapters[chapterIdx];
                                                const segmentIdx = chapter.segments.findIndex(s => s.id === bookmark.segmentId);

                                                if (segmentIdx !== -1) {
                                                    // If same chapter, just play
                                                    if (chapterIdx === currentChapterIndex) {
                                                        setCurrentSegmentIndex(segmentIdx);
                                                        // If we have audio files, play. If not, generate.
                                                        if (audioFiles.length > 0) {
                                                            playSegment(segmentIdx);
                                                        } else {
                                                            generateAudio(segmentIdx);
                                                        }
                                                    } else {
                                                        // Different chapter - set pending ref and switch chapter
                                                        pendingSegmentRef.current = segmentIdx;
                                                        setCurrentChapterIndex(chapterIdx);
                                                    }
                                                    setShowBookmarks(false);
                                                }
                                            }
                                        }}
                                        className="cursor-pointer"
                                    >
                                        <div className="flex justify-between items-start mb-1">
                                            <span className="text-xs font-mono text-yellow-500/70 uppercase">
                                                {bookmark.chapter?.title || "Chapter"}
                                            </span>
                                            <span className="text-xs text-gray-500">
                                                {new Date(bookmark.createdAt).toLocaleDateString()}
                                            </span>
                                        </div>
                                        <p className="text-gray-300 text-sm line-clamp-3 mb-2 font-serif italic">
                                            "{bookmark.previewText}"
                                        </p>
                                    </div>
                                    <div className="flex justify-end border-t border-white/5 pt-2">
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                // Optimistic delete
                                                setBookmarks(prev => prev.filter(b => b.id !== bookmark.id));
                                                axios.delete(`http://localhost:3000/api/bookmarks/${bookmark.id}`);
                                            }}
                                            className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                        >
                                            🗑 Remove
                                        </button>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}
