import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const API_KEY = process.env.GOOGLE_CLOUD_API_KEY;
const URL = 'https://texttospeech.googleapis.com/v1/text:synthesize';

async function testGoogleTTS() {
    console.log("Testing Google Cloud TTS...");
    console.log("Key:", API_KEY ? "Present" : "Missing");

    try {
        const response = await axios.post(`${URL}?key=${API_KEY}`, {
            input: { text: "Xin chào, đây là thử nghiệm giọng đọc Google Cloud." },
            voice: { languageCode: "vi-VN", name: "vi-VN-Standard-A" },
            audioConfig: { audioEncoding: "MP3" }
        });

        console.log("✅ Success! Status:", response.status);
        console.log("Audio Content Length:", response.data.audioContent.length);
    } catch (error: any) {
        console.error("❌ Failed!");
        console.error("Status:", error.response?.status);
        console.error("Data:", JSON.stringify(error.response?.data, null, 2));
    }
}

testGoogleTTS();
