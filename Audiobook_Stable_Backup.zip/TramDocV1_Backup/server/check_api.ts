
import axios from 'axios';
import dotenv from 'dotenv';
dotenv.config();

const API_KEY = process.env.GOOGLE_CLOUD_API_KEY;
const URL = `https://generativelanguage.googleapis.com/v1beta/models?key=${API_KEY}`;

async function checkApi() {
    console.log(`Checking API with key: ...${API_KEY?.slice(-4)}`);
    try {
        await axios.get(URL);
        console.log("✅ API Enabled");
    } catch (e: any) {
        if (e.response && e.response.status === 403) {
            console.log("❌ API Disabled or Key Restricted");
            // console.log(JSON.stringify(e.response.data));
        } else {
            console.log("❌ Error:", e.message);
        }
    }
}
checkApi();
