    /**
     * Clean metadata patterns from extracted text
     */
    private cleanMetadata(text: string): string {
    // Split text into words
    const words = text.split(/\s+/);

    // Detect repeated sequences at the beginning
    // Example: "Trại Súc Vật Trại Súc Vật" should remove first occurrence
    for (let wordCount = 1; wordCount <= 5 && wordCount * 2 <= words.length; wordCount++) {
        const firstPart = words.slice(0, wordCount).join(' ').toLowerCase();
        const secondPart = words.slice(wordCount, wordCount * 2).join(' ').toLowerCase();

        // If they match and it's meaningful (> 5 chars)
        if (firstPart === secondPart && firstPart.length > 5) {
            // Remove the first occurrence, keep second
            text = words.slice(wordCount).join(' ');
            console.log(`[cleanMetadata] Removed duplicate: "${firstPart}"`);
            break;
        }
    }

    return text.trim();
}
