import { VbeeTTSService } from './services/vbeeTTS.js';
import dotenv from 'dotenv';
import path from 'path';
dotenv.config({ path: path.join(process.cwd(), '.env') });
console.log('Current directory:', process.cwd());

async function test() {
    console.log('Testing Vbee TTS Service...');
    console.log('VBEE_API_KEY present:', !!process.env.VBEE_API_KEY);
    console.log('VBEE_APP_ID present:', !!process.env.VBEE_APP_ID);

    const service = new VbeeTTSService();
    try {
        const text = "Xin chào, đây là giọng đọc thử nghiệm từ Vbee.";
        const buffer = await service.synthesize(text, 'narrator');
        console.log(`Successfully generated audio buffer of size: ${buffer.length}`);
    } catch (error: any) {
        if (error.response) {
            console.error('Vbee API Error Status:', error.response.status);
            console.error('Vbee API Error Data:', JSON.stringify(error.response.data, null, 2));
        } else {
            console.error('Test failed:', error);
        }
    }
}

test();
