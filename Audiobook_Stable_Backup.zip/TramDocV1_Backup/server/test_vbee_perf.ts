import { VbeeTTSService } from './services/vbeeTTS.js';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.join(process.cwd(), '.env') });

async function runBenchmark() {
    console.log('🚀 Starting Vbee TTS Performance Benchmark...');
    const service = new VbeeTTSService();

    // Test 1: Single Request Latency
    console.log('\n--- Test 1: Single Request Latency ---');
    const startSingle = Date.now();
    try {
        await service.synthesize("Xin chào, đây là một câu thử nghiệm ngắn.", "narrator");
        const endSingle = Date.now();
        console.log(`✅ Single request took: ${(endSingle - startSingle) / 1000}s`);
    } catch (e: any) {
        console.error('❌ Single request failed:', e.message);
    }

    // Test 2: Concurrent Batch (5 requests)
    console.log('\n--- Test 2: Concurrent Batch (5 requests) ---');
    const segments = Array(5).fill(null).map((_, i) => ({
        content: `Đây là câu thử nghiệm số ${i + 1} để kiểm tra tốc độ xử lý đồng thời.`,
        role: "narrator" as const
    }));

    const startBatch = Date.now();
    try {
        await service.synthesizeSegments(segments);
        const endBatch = Date.now();
        console.log(`✅ Batch of 5 took: ${(endBatch - startBatch) / 1000}s`);
        console.log(`📊 Average per segment (effective): ${(endBatch - startBatch) / 5000}s`);
    } catch (e: any) {
        console.error('❌ Batch request failed:', e.message);
    }
}

runBenchmark();
