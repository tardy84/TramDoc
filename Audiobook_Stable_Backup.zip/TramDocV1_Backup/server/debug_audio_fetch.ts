
import axios from 'axios';
import fs from 'fs';
import path from 'path';

async function testAudioFetch() {
    try {
        // 1. Get a book and chapter
        console.log('Fetching books...');
        const booksRes = await axios.get('http://localhost:3000/api/books');
        const book = booksRes.data[0];
        if (!book) throw new Error('No books found');

        const chapter = book.chapters[0];
        if (!chapter) throw new Error('No chapters found');

        // Pick a segment deep in the chapter to force generation
        const targetIndex = Math.min(chapter.segments.length - 1, 50); // Try segment 50 or last one
        const manualUrl = `http://localhost:3000/audio/${book.id}_${chapter.id}_${targetIndex}.mp3`;

        console.log(`Requesting audio for: Book ${book.id}, Chapter ${chapter.id}, Segment ${targetIndex}`);
        console.log(`URL: ${manualUrl}`);

        const startTime = Date.now();
        const response = await axios.get(manualUrl, {
            responseType: 'arraybuffer',
            timeout: 60000 // 60s timeout
        });

        const duration = (Date.now() - startTime) / 1000;
        console.log(`✅ Success! Received ${response.data.length} bytes in ${duration}s`);

    } catch (error: any) {
        console.error('❌ Failed:', error.message);
        if (error.response) {
            console.error('Status:', error.response.status);
            console.error('Data:', Buffer.from(error.response.data).toString());
        }
    }
}

testAudioFetch();
