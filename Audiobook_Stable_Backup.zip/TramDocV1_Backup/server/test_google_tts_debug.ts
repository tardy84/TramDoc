
import dotenv from 'dotenv';
import { GoogleTTSService } from './services/googleTTS.js';
import fs from 'fs/promises';
import path from 'path';

dotenv.config();

async function testGoogleTTS() {
    console.log('--- Testing Google TTS Service ---');

    const apiKey = process.env.GOOGLE_CLOUD_API_KEY;
    if (!apiKey) {
        console.error('❌ GOOGLE_CLOUD_API_KEY is missing in .env');
        return;
    }

    console.log(`✅ API Key found: ${apiKey.substring(0, 5)}...${apiKey.substring(apiKey.length - 4)}`);

    const ttsService = new GoogleTTSService();

    try {
        console.log('Attempting to synthesize text: "Xin chào, đây là kiểm tra giọng nói."');
        const buffer = await ttsService.synthesize("Xin chào, đây là kiểm tra giọng nói.", "narrator");

        console.log(`✅ Synthesis successful! Buffer size: ${buffer.length} bytes`);

        const outputPath = path.join(process.cwd(), 'test_google_tts_output.mp3');
        await fs.writeFile(outputPath, buffer);
        console.log(`✅ Saved audio to ${outputPath}`);

    } catch (error: any) {
        console.error('❌ Synthesis failed!');
        if (error.response) {
            console.error('Status:', error.response.status);
            console.error('Data:', JSON.stringify(error.response.data, null, 2));
        } else {
            console.error('Error:', error.message);
        }
    }
}

testGoogleTTS();
