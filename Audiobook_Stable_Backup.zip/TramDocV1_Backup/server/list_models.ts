
import axios from 'axios';
import dotenv from 'dotenv';
dotenv.config();

const API_KEY = process.env.GOOGLE_CLOUD_API_KEY;
const URL = `https://generativelanguage.googleapis.com/v1beta/models?key=${API_KEY}`;

async function listModels() {
    try {
        const response = await axios.get(URL);
        response.data.models.forEach((m: any) => {
            if (m.name.includes('flash')) console.log(m.name);
        });
    } catch (e: any) {
        console.error(e.message);
    }
}
listModels();
