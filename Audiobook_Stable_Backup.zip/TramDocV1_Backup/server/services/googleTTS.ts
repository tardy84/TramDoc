import axios from 'axios';

const GOOGLE_CLOUD_API_KEY = process.env.GOOGLE_CLOUD_API_KEY;
const TTS_API_URL = 'https://texttospeech.googleapis.com/v1/text:synthesize';

interface VoiceConfig {
    languageCode: string;
    name: string;
    ssmlGender: 'MALE' | 'FEMALE' | 'NEUTRAL';
}

export class GoogleTTSService {
    private voiceMap: Record<string, VoiceConfig> = {
        narrator: {
            languageCode: 'vi-VN',
            name: 'vi-VN-Standard-A',
            ssmlGender: 'FEMALE', // Changed to correct gender (A is female)
        },
        male: {
            languageCode: 'vi-VN',
            name: 'vi-VN-Standard-B',
            ssmlGender: 'MALE',
        },
        female: {
            languageCode: 'vi-VN',
            name: 'vi-VN-Standard-C',
            ssmlGender: 'FEMALE',
        },
        child: {
            languageCode: 'vi-VN',
            name: 'vi-VN-Standard-D', // Often used as child/male variant
            ssmlGender: 'MALE',
        },
        dialogue: {
            languageCode: 'vi-VN',
            name: 'vi-VN-Standard-D', // Use distinct male voice for generic dialogue
            ssmlGender: 'MALE',
        }
    };

    async synthesize(
        text: string,
        role: 'narrator' | 'male' | 'female' | 'child' | 'dialogue',
        voiceOverride?: string
    ): Promise<Buffer> {
        // Apply override if provided (name only for now, assume vi-VN)
        // If override is present, use it regardless of role!
        if (voiceOverride) {
            voice = {
                languageCode: 'vi-VN',
                name: voiceOverride,
                ssmlGender: 'FEMALE' // Default to female for single voice, or lookup if needed
            };
        } else {
            voice = this.voiceMap[role] || this.voiceMap['narrator'];
        }
        voice = {
            ...voice,
            name: voiceOverride
        };
    }

    const response = await axios.post(
        `${TTS_API_URL}?key=${GOOGLE_CLOUD_API_KEY}`,
        {
            input: { text },
            voice: {
                languageCode: voice.languageCode,
                name: voice.name,
                ssmlGender: voice.ssmlGender,
            },
            audioConfig: {
                audioEncoding: 'MP3', // Mobile/Browser compatible
                speakingRate: 1.0,
                pitch: 0,
            },
        }
    );

        // Google returns base64 encoded audio
        return Buffer.from(response.data.audioContent, 'base64');
    }

    async synthesizeSegments(
        segments: Array<{ content: string; role: 'narrator' | 'male' | 'female' | 'child' | 'dialogue' }>,
        voiceOverride ?: string
    ): Promise < Buffer[] > {
        // Process all segments in parallel for much faster generation
        console.log(`[TTS] Starting parallel generation for ${segments.length} segments...`);
        const startTime = Date.now();

        const audioBuffers = await Promise.all(
            segments.map(segment => this.synthesize(segment.content, segment.role, voiceOverride))
        );

        const duration = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[TTS] ✅ Generated ${segments.length} segments in ${duration}s (parallel)`);

        return audioBuffers;
    }
}
