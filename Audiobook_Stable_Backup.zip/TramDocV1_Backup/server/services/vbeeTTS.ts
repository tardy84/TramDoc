import axios from 'axios';

const VBEE_API_URL = 'https://vbee.vn/api/v1/tts';

interface VoiceConfig {
    voice_code: string;
}

export class VbeeTTSService {
    private voiceMap: Record<string, VoiceConfig> = {
        narrator: {
            // SG Male - Thiện Tâm (User Request)
            voice_code: 's_sg_male_thientam_ytstable_vc',
        },
        male: {
            voice_code: 's_sg_male_thientam_ytstable_vc',
        },
        female: {
            voice_code: 's_sg_male_thientam_ytstable_vc',
        },
        child: {
            voice_code: 's_sg_male_thientam_ytstable_vc',
        },
        dialogue: {
            voice_code: 's_sg_male_thientam_ytstable_vc',
        }
    };

    /**
     * Synthesize text to speech using Vbee API
     */
    async synthesize(
        text: string,
        role: 'narrator' | 'male' | 'female' | 'child' | 'dialogue',
        voiceOverride?: string
    ): Promise<Buffer> {
        const VBEE_API_KEY = process.env.VBEE_API_KEY; // Bearer Token
        const VBEE_APP_ID = process.env.VBEE_APP_ID;

        if (!VBEE_API_KEY || !VBEE_APP_ID) {
            throw new Error('Missing Vbee credentials in .env');
        }

        // Use role-based mapping or override
        let voiceCode = this.voiceMap[role]?.voice_code || this.voiceMap['narrator'].voice_code;

        if (voiceOverride) {
            voiceCode = voiceOverride;
        }

        console.log(`[Vbee] Synthesizing '${role}' with voice: ${voiceCode}`);

        try {
            // 1. Request audio generation (Direct Stream)
            // Note: response_type 'direct' should return audio binary.
            // But we must request responseType: 'arraybuffer' in axios.
            const response = await axios.post(
                VBEE_API_URL,
                {
                    input_text: text,
                    app_id: VBEE_APP_ID,
                    voice_code: voiceCode,
                    audio_type: 'mp3',
                    response_type: 'direct'
                },
                {
                    headers: {
                        'Authorization': `Bearer ${VBEE_API_KEY}`,
                        'app-id': VBEE_APP_ID,
                        'Content-Type': 'application/json'
                    },
                    responseType: 'arraybuffer',
                    timeout: 30000 // 30s timeout
                }
            );

            // If success, response.data IS the buffer.

            const contentType = response.headers['content-type'];
            if (contentType && contentType.includes('application/json')) {
                // It is a JSON response (link or error)
                const jsonStr = Buffer.from(response.data).toString('utf8');
                try {
                    const jsonData = JSON.parse(jsonStr);

                    // Check for error (Vbee uses status: 1 for success)
                    if (jsonData.status !== 1 && jsonData.error_code !== 0) {
                        throw new Error(`Vbee API Error: ${jsonStr}`);
                    }

                    // Extract audio link (could be at root or in result)
                    const audioUrl = jsonData.audio_link || jsonData.result?.audio_link;

                    if (audioUrl) {
                        // Fetch the actual audio
                        const audioResponse = await axios.get(audioUrl, {
                            responseType: 'arraybuffer'
                        });
                        return Buffer.from(audioResponse.data);
                    } else {
                        throw new Error(`Vbee returned JSON without audio_link: ${jsonStr}`);
                    }
                } catch (e: any) {
                    if (e.message.includes('Vbee')) throw e;
                    console.warn('[Vbee] Failed to parse JSON response, returning raw buffer:', e);
                }
            }

            return Buffer.from(response.data);

        } catch (error: any) {
            // If error, response.data might be a JSON error message in buffer format
            if (error.response && error.response.data) {
                try {
                    const errorText = Buffer.from(error.response.data).toString('utf8');
                    throw new Error(`Vbee API Error: ${errorText}`);
                } catch (e) {
                    // ignore
                }
            }
            throw error;
        }
    }

    async synthesizeSegments(
        segments: Array<{ content: string; role: 'narrator' | 'male' | 'female' | 'child' | 'dialogue' }>,
        voiceOverride?: string
    ): Promise<Buffer[]> {
        console.log(`[TTS] Starting Vbee generation for ${segments.length} segments...`);
        if (voiceOverride) {
            console.log(`[TTS] ⚠️ Using voice override: ${voiceOverride}`);
        } else {
            console.log(`[TTS] Using role-based voices (Narrator: ${this.voiceMap['narrator'].voice_code})`);
        }

        const startTime = Date.now();

        const audioBuffers: Buffer[] = new Array(segments.length);
        const BATCH_SIZE = 10; // Optimized for speed

        for (let i = 0; i < segments.length; i += BATCH_SIZE) {
            const batch = segments.slice(i, i + BATCH_SIZE);
            console.log(`[TTS] Processing batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(segments.length / BATCH_SIZE)}...`);

            await Promise.all(batch.map(async (segment, index) => {
                const globalIndex = i + index;
                try {
                    // Log what we are doing
                    const appliedVoice = voiceOverride || (this.voiceMap[segment.role] || this.voiceMap['narrator']).voice_code;
                    // console.log(`[TTS] Segment "${segment.content.substring(0, 15)}..." [${segment.role}] -> ${appliedVoice}`);

                    const buffer = await this.synthesize(segment.content, segment.role, voiceOverride);
                    audioBuffers[globalIndex] = buffer;
                } catch (error) {
                    console.error(`[TTS] Failed segment "${segment.content.substring(0, 20)}...":`, error);
                    throw error;
                }
            }));

            // Small delay between batches to be nice to the API
            if (i + BATCH_SIZE < segments.length) {
                await new Promise(resolve => setTimeout(resolve, 50));
            }
        }

        const duration = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[TTS] ✅ Generated ${segments.length} segments in ${duration}s via Vbee`);

        return audioBuffers;
    }
}
