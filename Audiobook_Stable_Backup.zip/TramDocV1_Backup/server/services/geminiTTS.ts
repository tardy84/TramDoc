
import axios from 'axios';

// const API_KEY = process.env.GOOGLE_CLOUD_API_KEY; // Moved to method scope
// Using dedicated TTS model found in list
const MODEL_NAME = 'gemini-2.5-flash-preview-tts';
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL_NAME}:generateContent`;

// Map roles to specific Gemini voices
// Map roles to specific Gemini voices
const ROLE_VOICE_MAP: Record<string, string> = {
    narrator: 'Aoede',
    male: 'Aoede',
    female: 'Aoede',
    child: 'Aoede',
    dialogue: 'Aoede'
};

export class GeminiTTSService {
    private lastRequestTime = 0;
    private readonly MIN_REQUEST_INTERVAL = 10000; // 10 seconds (Very safe)

    private async waitForRateLimit() {
        const now = Date.now();
        const timeSinceLastRequest = now - this.lastRequestTime;

        if (timeSinceLastRequest < this.MIN_REQUEST_INTERVAL) {
            const waitTime = this.MIN_REQUEST_INTERVAL - timeSinceLastRequest;
            console.log(`[GeminiTTS] Throttling for ${waitTime}ms...`);
            await new Promise(resolve => setTimeout(resolve, waitTime));
        }
    }

    private requestQueue: Promise<any> = Promise.resolve();

    async synthesize(
        text: string,
        role: 'narrator' | 'male' | 'female' | 'child' | 'dialogue',
        voiceOverride?: string
    ): Promise<Buffer> {
        // Chain requests to ensure strict sequential execution
        const result = this.requestQueue.then(async () => {
            await this.waitForRateLimit();
            return this.executeSynthesize(text, role, voiceOverride);
        });

        // Update queue to wait for this request (catch errors to keep queue alive)
        this.requestQueue = result.catch(() => { });

        return result;
    }

    private async executeSynthesize(
        text: string,
        role: 'narrator' | 'male' | 'female' | 'child' | 'dialogue',
        voiceOverride?: string
    ): Promise<Buffer> {
        // Select voice based on override or role
        const voiceName = voiceOverride || ROLE_VOICE_MAP[role] || 'Aoede';

        const payload = {
            contents: [{
                parts: [{ text: text }]
            }],
            generationConfig: {
                response_modalities: ["AUDIO"],
                speech_config: {
                    voice_config: {
                        prebuilt_voice_config: {
                            voice_name: voiceName
                        }
                    }
                }
            }
        };

        try {
            const apiKey = process.env.GOOGLE_CLOUD_API_KEY;
            if (!apiKey) throw new Error("GOOGLE_CLOUD_API_KEY is missing");

            const response = await axios.post(`${API_URL}?key=${apiKey}`, payload);
            this.lastRequestTime = Date.now(); // Update timestamp AFTER successful request

            // Accessing the audio content correctly based on Gemini 1.5/2.0 Flash output format
            // note: inlineData might be under candidates[0].content.parts[0].inlineData
            const candidate = response.data.candidates?.[0];
            const inlineData = candidate?.content?.parts?.[0]?.inlineData;

            if (inlineData && inlineData.mimeType.startsWith('audio/')) {
                console.log(`[GeminiTTS] Received MIME Type: ${inlineData.mimeType}`);
                const pcmData = Buffer.from(inlineData.data, 'base64');

                // Gemini usually returns 24kHz, 1 channel, 16-bit PCM
                // MimeType example: "audio/L16;codec=pcm;rate=24000"
                const sampleRate = 24000;

                // Wrap in WAV header
                const wavBuffer = this.addWavHeader(pcmData, sampleRate);
                console.log(`[GeminiTTS] Converted to WAV. Total size: ${wavBuffer.length}`);
                return wavBuffer;
            }

            throw new Error(`No audio data returned. Response: ${JSON.stringify(response.data)}`);

        } catch (error: any) {
            console.error('Gemini TTS Error Status:', error.response?.status);
            console.error('Gemini TTS Error Data:', JSON.stringify(error.response?.data || error.message, null, 2));
            // Don't update lastRequestTime on error to allow immediate retry? 
            // Or update it to prevent hammering? 
            // Better to update it to be safe.
            this.lastRequestTime = Date.now();
            throw error;
        }
    }

    private addWavHeader(samples: Buffer, sampleRate: number): Buffer {
        const numChannels = 1;
        const bitsPerSample = 16;
        const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
        const blockAlign = (numChannels * bitsPerSample) / 8;
        const subChunk2Size = samples.length;
        const chunkSize = 36 + subChunk2Size;

        const header = Buffer.alloc(44);

        // RIFF chunk descriptor
        header.write('RIFF', 0);
        header.writeUInt32LE(chunkSize, 4);
        header.write('WAVE', 8);

        // fmt sub-chunk
        header.write('fmt ', 12);
        header.writeUInt32LE(16, 16); // SubChunk1Size (16 for PCM)
        header.writeUInt16LE(1, 20);  // AudioFormat (1 for PCM)
        header.writeUInt16LE(numChannels, 22);
        header.writeUInt32LE(sampleRate, 24);
        header.writeUInt32LE(byteRate, 28);
        header.writeUInt16LE(blockAlign, 32);
        header.writeUInt16LE(bitsPerSample, 34);

        // data sub-chunk
        header.write('data', 36);
        header.writeUInt32LE(subChunk2Size, 40);

        return Buffer.concat([header, samples]);
    }

    async synthesizeSegments(
        segments: Array<{ content: string; role: 'narrator' | 'male' | 'female' | 'child' | 'dialogue' }>,
        voiceOverride?: string
    ): Promise<Buffer[]> {
        // Processing sequentially is required for rate limiting
        console.log(`[GeminiTTS] Generating ${segments.length} segments sequentially...`);
        const audioBuffers: Buffer[] = [];

        for (const [index, segment] of segments.entries()) {
            try {
                // The throttle logic is now inside synthesize()
                const voiceName = voiceOverride || ROLE_VOICE_MAP[segment.role] || 'Default';
                console.log(`[GeminiTTS] Processing segment ${index + 1}/${segments.length} (Voice: ${voiceName})...`);
                const buffer = await this.synthesize(segment.content, segment.role, voiceOverride);
                audioBuffers.push(buffer);
            } catch (error) {
                console.error(`[GeminiTTS] Failed to generate segment ${index}:`, error);
                throw error;
            }
        }

        return audioBuffers;
    }
}
