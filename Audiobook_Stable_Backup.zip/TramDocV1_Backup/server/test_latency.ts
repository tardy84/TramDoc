
import { GeminiTTSService } from './services/geminiTTS.js';
import dotenv from 'dotenv';

dotenv.config();

async function testLatency() {
    const tts = new GeminiTTSService();
    const text = "This is a test sentence to measure generation time.";

    console.log("Starting latency test...");
    const start = Date.now();
    try {
        await tts.synthesize(text, "narrator");
        const end = Date.now();
        console.log(`Generation took ${end - start}ms`);
    } catch (error) {
        console.error("Generation failed:", error);
    }
}

testLatency();
