
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const API_KEY = process.env.GOOGLE_CLOUD_API_KEY;
const MODEL_NAME = 'gemini-2.0-flash-exp'; // Trying a known model, maybe the TTS one is different?
// The user code used: 'gemini-2.5-flash-preview-tts' which might not exist or be public yet?
// Let's try to list models first or just test the failing call.

// Let's recreate the EXACT failing call first.
const TEST_MODEL = 'gemini-2.0-flash-exp'; // Reverting to a known model just to check if it accepts audio config? 
// Actually, let's stick to the one in the code first to see the error.
const BROKEN_MODEL = 'gemini-2.5-flash-preview-tts';

const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${BROKEN_MODEL}:generateContent`;

async function testTTS() {
    console.log(`Testing Gemini TTS with model: ${BROKEN_MODEL}`);
    console.log(`API Key present: ${!!API_KEY}`);

    const payload = {
        contents: [{
            parts: [{ text: "Hello, this is a test of the Gemini Text to Speech system." }]
        }],
        generationConfig: {
            response_modalities: ["AUDIO"],
            audio_encoding: "MP3",
            audio_timestamp: true, // Optional debug
            speech_config: {
                voice_config: {
                    prebuilt_voice_config: {
                        voice_name: "Aoede"
                    }
                }
            }
        }
    };

    try {
        const response = await axios.post(`${API_URL}?key=${API_KEY}`, payload);
        console.log('Success!');
        console.log('Response keys:', Object.keys(response.data));
        const candidate = response.data.candidates?.[0];
        const inlineData = candidate?.content?.parts?.[0]?.inlineData;
        if (inlineData) {
            console.log('Audio Data Present:', inlineData.mimeType);
            console.log('Data Length:', inlineData.data.length);
        } else {
            console.error('❌ NO AUDIO DATA IN RESPONSE!');
            console.log(JSON.stringify(response.data, null, 2));
        }
    } catch (error: any) {
        console.error('TTS Generation Failed!');
        console.error('Error Status:', error.response?.status);
        if (error.response?.data) {
            console.error('Error Data:', JSON.stringify(error.response.data, null, 2));
        } else {
            console.error('Error Message:', error.message);
        }
    }
}

testTTS();
