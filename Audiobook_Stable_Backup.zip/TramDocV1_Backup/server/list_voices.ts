import axios from 'axios';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.join(process.cwd(), '.env') });

async function listVoices() {
    console.log('Fetching Vbee Voices...');
    try {
        const response = await axios.get('https://vbee.vn/api/v1/voices', {
            headers: {
                'Authorization': `Bearer ${process.env.VBEE_API_KEY}`,
                'app-id': process.env.VBEE_APP_ID
            }
        });

        // Note: Browser subagent said https://vbee.vn/api/public/v1/voices
        // Let's try that if this fails. But let's look at output.
        console.log('Status:', response.status);
        if (Array.isArray(response.data)) {
            // ... (unreachable)
        } else {
            console.log('Response keys:', Object.keys(response.data));
            let voicesArray: any[] = [];

            // Check if 'result' is the array (it wasn't based on previous logs)
            // Check if 'result' is an object that contains the array
            if (response.data.result && !Array.isArray(response.data.result)) {
                console.log('Result keys:', Object.keys(response.data.result));
                const possibleInnerKeys = ['data', 'voices', 'payload', 'items'];
                for (const key of possibleInnerKeys) {
                    if (Array.isArray(response.data.result[key])) {
                        console.log(`Found array in result.${key}`);
                        voicesArray = response.data.result[key];
                        break;
                    }
                }
            }

            // Fallback to top-level search if not found
            if (voicesArray.length === 0) {
                const possibleKeys = ['data', 'voices', 'payload', 'items', 'result'];
                for (const key of possibleKeys) {
                    if (Array.isArray(response.data[key])) {
                        voicesArray = response.data[key];
                        break;
                    }
                }
            }

            if (voicesArray.length > 0) {
                const vnVoices = voicesArray.filter((v: any) => v.language && v.language.code === 'vi-VN');
                console.log('Vietnamese Voices found:', vnVoices.length);
                vnVoices.forEach((v: any) => console.log(`- ${v.name} (${v.gender}): ${v.code}`));
            } else {
                console.log('Could not find voices array in response.');
            }
        }
    } catch (error: any) {
        console.error('Error fetching voices:', error.message);
        if (error.response) {
            console.error('Data:', JSON.stringify(error.response.data, null, 2));
        }
    }
}


listVoices();

