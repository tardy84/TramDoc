
import { GeminiTTSService } from './services/geminiTTS.js';
import dotenv from 'dotenv';
import fs from 'fs/promises';

const result = dotenv.config({ path: '.env' });
console.log("Dotenv result:", result.error ? result.error : "Success");
console.log("API Key loaded:", process.env.GOOGLE_CLOUD_API_KEY ? "YES" : "NO");

async function testWavGeneration() {
    console.log("Testing Gemini TTS WAV Generation...");
    const tts = new GeminiTTSService();
    const text = "Testing audio generation with WAV header.";

    try {
        console.log("Synthesizing...");
        const audioBuffer = await tts.synthesize(text, "narrator");
        console.log(`Generation complete. Buffer size: ${audioBuffer.length}`);

        // Check header
        const header = audioBuffer.subarray(0, 44);
        console.log("Header Hex:", header.toString('hex'));

        const riff = header.subarray(0, 4).toString();
        const wave = header.subarray(8, 12).toString();

        if (riff === 'RIFF' && wave === 'WAVE') {
            console.log("✅ Valid WAV Header detected!");
            await fs.writeFile('debug_output.wav', audioBuffer);
            console.log("Saved to debug_output.wav");
        } else {
            console.error("❌ Invalid WAV Header!");
        }

    } catch (error: any) {
        console.error("❌ Generation Failed!");
        if (error.response) {
            console.error("Status:", error.response.status);
            console.error("Headers:", JSON.stringify(error.response.headers, null, 2));
            console.error("Data:", JSON.stringify(error.response.data, null, 2));
        } else {
            console.error("Error:", error.message);
        }
    }
}

testWavGeneration();
