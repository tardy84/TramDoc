import express from 'express';
import type { Request, Response } from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import { PrismaClient } from '@prisma/client';
import dotenv from 'dotenv';
import { EpubProcessor } from './services/epubProcessor.js';
import { GoogleTTSService } from './services/googleTTS.js';
import { VbeeTTSService } from './services/vbeeTTS.js';
import { GeminiTTSService } from './services/geminiTTS.js';
import fs from 'fs/promises';

dotenv.config();

const app = express();
// Extend PrismaClient to include bookmark if not automatically detected (though generate should fix this)
const prisma = new PrismaClient({});
const epubProcessor = new EpubProcessor();
const ttsService = new GoogleTTSService();
// const ttsService = new VbeeTTSService();
// const ttsService = new GeminiTTSService();
const port = process.env.PORT || 3000;

console.log("--- SUPER UNIQUE VERSION: XYZ_123_ABC ---");
console.log("--- IF YOU SEE THIS, THE CODE IS UPDATED ---");

app.use(cors());
app.use(express.json());

// Upload configuration
const upload = multer({ dest: 'uploads/' });

// Static files for audio
// Dynamic Audio Serving (On-Demand Generation)
// Static files for audio - Handled by dynamic route at bottom
// app.get('/audio/:filename'...) removed to prevent duplicate handling logic shadowing the improved lookahead version

// Static files for cover images
app.use('/covers', express.static('uploads/covers'));

// Basic health check
app.get('/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', timestamp: new Date() });
});

// EPUB upload and processing
app.post('/api/upload', upload.single('book'), async (req: Request, res: Response) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        // Process the EPUB file
        const bookId = await epubProcessor.processEpub(req.file.path);

        res.json({
            message: 'EPUB processed successfully',
            bookId,
        });
    } catch (error: any) {
        console.error('Error processing EPUB:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get all books
app.get('/api/books', async (req: Request, res: Response) => {
    const books = await prisma.book.findMany({
        include: { chapters: { include: { segments: true }, orderBy: { orderIndex: 'asc' } } }
    });

    // Transform books to include coverImageUrl
    const transformedBooks = books.map(book => ({
        ...book,
        coverImageUrl: book.coverImagePath ? `/covers/${path.basename(book.coverImagePath)}` : null,
        // Filter out ToC from regular chapters but keep all for now (will add separate ToC field later if needed)
        chapters: book.chapters,
    }));

    res.json(transformedBooks);
});

// Delete a book and its associated files
app.delete('/api/books/:id', async (req: Request, res: Response) => {
    try {
        const bookId = parseInt(req.params.id as string);

        // Get book data before deletion to access file paths
        const book = await prisma.book.findUnique({
            where: { id: bookId },
            include: { chapters: true }
        });

        if (!book) {
            return res.status(404).json({ error: 'Book not found' });
        }

        // Delete from database (cascade will handle chapters and segments)
        await prisma.book.delete({
            where: { id: bookId }
        });

        // Clean up files
        const filesToDelete: string[] = [];

        // Add cover image if exists
        if (book.coverImagePath) {
            filesToDelete.push(book.coverImagePath);
        }

        // Delete files asynchronously (don't block response)
        Promise.all(
            filesToDelete.map(async (filePath) => {
                try {
                    await fs.unlink(filePath);
                    console.log(`[DELETE] Removed file: ${filePath}`);
                } catch (error) {
                    console.warn(`[DELETE] Failed to remove file ${filePath}:`, error);
                }
            })
        ).catch(err => console.error('[DELETE] File cleanup error:', err));

        res.json({ message: 'Book deleted successfully', bookId });
    } catch (error: any) {
        console.error('Error deleting book:', error);
        res.status(500).json({ error: error.message });
    }
});

// --- Bookmark Endpoints ---

// Get all bookmarks for a book
app.get('/api/books/:bookId/bookmarks', async (req: Request, res: Response) => {
    try {
        const bookId = parseInt(req.params.bookId as string);
        const bookmarks = await prisma.bookmark.findMany({
            where: { bookId },
            orderBy: { createdAt: 'desc' },
            include: {
                chapter: {
                    select: { title: true, orderIndex: true }
                }
            }
        });
        res.json(bookmarks);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Create a bookmark
app.post('/api/bookmarks', async (req: Request, res: Response) => {
    try {
        const { bookId, chapterId, segmentId, previewText, note } = req.body;

        const bookmark = await prisma.bookmark.create({
            data: {
                bookId: parseInt(bookId),
                chapterId: parseInt(chapterId),
                segmentId: parseInt(segmentId),
                previewText,
                note
            }
        });
        res.json(bookmark);
    } catch (error: any) {
        console.error('Create bookmark error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Delete a bookmark
app.delete('/api/bookmarks/:id', async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id as string);
        await prisma.bookmark.delete({ where: { id } });
        res.json({ success: true });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Generate TTS for a specific book chapter
app.post('/api/books/:bookId/chapters/:chapterId/tts', async (req: Request, res: Response) => {
    try {
        const { bookId, chapterId } = req.params;

        const chapter = await prisma.chapter.findFirst({
            where: {
                id: parseInt(chapterId as string),
                bookId: parseInt(bookId as string),
            },
            include: { segments: { orderBy: { orderIndex: 'asc' } } },
        });

        if (!chapter) {
            return res.status(404).json({ error: 'Chapter not found' });
        }

        await fs.mkdir('audio', { recursive: true });

        // CACHE DISABLED - To allow voice/engine changes
        // TODO: Re-enable cache with voice settings in cache key
        // Check if audio files already exist (caching)
        const audioFiles: string[] = [];
        let allCached = true;

        for (let i = 0; i < chapter.segments.length; i++) {
            const fileName = `${bookId}_${chapterId}_${i}.mp3`;
            const filePath = `audio/${fileName}`;

            try {
                await fs.access(filePath);
                // File exists, use cached version
                // Add timestamp to foil browser cache if file changed recently, but here we assume file is immutable for now
                audioFiles.push(`/audio/${fileName}`);
            } catch {
                // File doesn't exist
                allCached = false;
                // If we want partial result, we could push null or placeholder, but for now just mark flag
            }
        }

        // If all audio files are cached, return immediately
        if (allCached && audioFiles.length === chapter.segments.length) {
            console.log(`[TTS Cache] ✅ Using cached audio for book ${bookId}, chapter ${chapterId} (${audioFiles.length} segments)`);
            return res.json({ audioFiles });
        }

        // Generate audio for all segments (Only missing ones ideally)
        console.log(`[TTS] Generating audio for book ${bookId}, chapter ${chapterId}`);
        const { voice } = req.body; // Check for voice override

        const totalSegments = chapter.segments.length;
        const PRELOAD_COUNT = 1; // Generate ONLY the first segment immediately to prevent timeout

        // Prepare File Names List (re-populate to ensure correct order/paths)
        const timestamp = Date.now();
        const responseAudioFiles: string[] = [];
        for (let i = 0; i < totalSegments; i++) {
            responseAudioFiles.push(`/audio/${bookId}_${chapterId}_${i}.mp3?t=${timestamp}`);
        }

        // Split segments
        const initialSegments = chapter.segments.slice(0, PRELOAD_COUNT);
        const remainingSegments = chapter.segments.slice(PRELOAD_COUNT);

        // 1. Generate Initial Batch (Blocking) - INTELLIGENT CACHE CHECK
        console.log(`[TTS] 🚀 Checking/Generating initial batch (${initialSegments.length}/${totalSegments})...`);

        const segmentsToGenerate: { content: string, role: string, index: number }[] = [];

        // Check which of the initial ones actually need generation
        for (let i = 0; i < initialSegments.length; i++) {
            const fileName = `${bookId}_${chapterId}_${i}.mp3`;
            const filePath = `audio/${fileName}`;
            try {
                await fs.access(filePath);
                console.log(`[TTS] Segment ${i} already exists, skipping generation.`);
            } catch {
                segmentsToGenerate.push({
                    content: initialSegments[i].content,
                    role: initialSegments[i].role,
                    index: i
                });
            }
        }

        if (segmentsToGenerate.length > 0) {
            console.log(`[TTS] Generating ${segmentsToGenerate.length} missing initial segments...`);
            const generatedBuffers = await ttsService.synthesizeSegments(
                segmentsToGenerate.map(s => ({ content: s.content, role: s.role as any })),
                voice
            );

            // Write Generated Buffers
            for (let i = 0; i < generatedBuffers.length; i++) {
                const item = segmentsToGenerate[i];
                const fileName = `${bookId}_${chapterId}_${item.index}.mp3`;
                const filePath = `audio/${fileName}`;
                await fs.writeFile(filePath, generatedBuffers[i]);
            }
        }

        // 2. Generate Remaining Batch (Background)
        if (remainingSegments.length > 0) {
            // Do not await!
            (async () => {
                const CONCURRENCY = 5;
                console.log(`[TTS] ⏳ Starting background generation for ${remainingSegments.length} segments (Concurrency: ${CONCURRENCY})...`);

                for (let i = 0; i < remainingSegments.length; i += CONCURRENCY) {
                    const batch = remainingSegments.slice(i, i + CONCURRENCY);
                    await Promise.all(batch.map(async (segment, index) => {
                        const globalIndex = PRELOAD_COUNT + i + index;
                        await generateSegment(parseInt(bookId), parseInt(chapterId), globalIndex, voice);
                    }));
                }
                console.log(`[TTS] 🎉 All background generation complete for chapter ${chapterId}`);
            })();
        }

        res.json({ audioFiles: responseAudioFiles });
    } catch (error: any) {
        console.error('Error generating TTS:', error);
        res.status(500).json({ error: error.message });
    }
});

// Helper for generating a specific segment (Deduped + Safe)
const generatingFiles = new Set<string>();

async function generateSegment(bookId: number, chapterId: number, segmentIndex: number, voice?: string): Promise<boolean> {
    const fileName = `${bookId}_${chapterId}_${segmentIndex}.mp3`;
    const filePath = path.join(process.cwd(), 'audio', fileName);

    // 1. Check if already exists
    try {
        await fs.access(filePath);
        return true; // Exists
    } catch {
        // Continue
    }

    // 2. Check if currently generating (Dedup)
    // 2. Check if currently generating (Dedup)
    if (generatingFiles.has(fileName)) {
        console.log(`[Audio] ⏳ File ${fileName} is already being generated. Waiting...`);
        // Wait for it to finish (poll every 500ms, max 30s)
        const MAX_WAIT = 60; // 30s / 0.5s
        let attempts = 0;

        while (generatingFiles.has(fileName) && attempts < MAX_WAIT) {
            await new Promise(resolve => setTimeout(resolve, 500));
            attempts++;
        }

        // After waiting, check if file exists
        try {
            await fs.access(filePath);
            console.log(`[Audio] ✅ File ${fileName} ready after wait.`);
            return true;
        } catch {
            console.error(`[Audio] ❌ File ${fileName} not found after waiting.`);
            return false;
        }
    }

    generatingFiles.add(fileName);

    try {
        // Fetch DB Segment
        const segment = await prisma.textSegment.findFirst({
            where: { chapterId, orderIndex: segmentIndex }
        });

        if (!segment) {
            generatingFiles.delete(fileName);
            return false;
        }

        const buffer = await ttsService.synthesize(
            segment.content,
            segment.role as any,
            voice
        );

        await fs.writeFile(filePath, buffer);
        console.log(`[Audio] ✅ Generated: ${fileName}`);
        return true;
    } catch (error) {
        console.error(`[Audio] ❌ Failed to generate ${fileName}:`, error);
        return false;
    } finally {
        generatingFiles.delete(fileName);
    }
}

// Dynamic Audio Serving (On-Demand Generation + Lookahead)
app.get('/audio/:filename', async (req: Request, res: Response) => {
    const { filename } = req.params;
    const filePath = path.join(process.cwd(), 'audio', filename);

    // Parse filename info
    // Parse filename info
    const baseName: string = filename.split('.')[0];
    const parts = baseName.split('_');
    // Removing query params from filename if present in request param (express usually handles this, 
    // but client sends ?t=..., express :filename does NOT include query string. So this is safe.)

    // Basic existence check
    try {
        await fs.access(filePath);
        return res.sendFile(filePath);
    } catch {
        // File missing
    }

    if (parts.length < 3) return res.status(400).send('Invalid');

    const bookId = parseInt(parts[0]);
    const chapterId = parseInt(parts[1]);
    const segmentIndex = parseInt(parts[2]);

    console.log(`[Audio] ⚠️ Cache Miss: ${filename}. Generating on-demand...`);

    try {
        // 1. Generate requested file (Blocking)
        await generateSegment(bookId, chapterId, segmentIndex);

        // 2. Lookahead: Trigger generation for next 3 segments (Non-Blocking)
        // This ensures smooth playback when user jumps
        (async () => {
            console.log(`[Audio] 🔮 Triggering lookahead for segments ${segmentIndex + 1}..${segmentIndex + 3}`);
            await generateSegment(bookId, chapterId, segmentIndex + 1);
            await generateSegment(bookId, chapterId, segmentIndex + 2);
            await generateSegment(bookId, chapterId, segmentIndex + 3);
        })();

        // 3. Serve file
        res.sendFile(filePath);
    } catch (error) {
        res.status(500).send('Gen Failed');
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
