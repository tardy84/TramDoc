
import axios from 'axios';
import fs from 'fs';

const BASE_URL = 'http://localhost:3000';

async function testAudioGeneration() {
    try {
        // 1. Get books
        console.log("Fetching books...");
        const booksRes = await axios.get(`${BASE_URL}/api/books`);
        const books = booksRes.data;

        if (books.length === 0) {
            console.log("No books found. Please upload a book first.");
            return;
        }

        const book = books[0];
        const chapter = book.chapters[0];

        console.log(`Testing with Book: ${book.title} (ID: ${book.id}), Chapter: ${chapter.title} (ID: ${chapter.id})`);

        // 2. Trigger TTS
        console.log("Triggering TTS...");
        const ttsStart = Date.now();
        const ttsRes = await axios.post(`${BASE_URL}/api/books/${book.id}/chapters/${chapter.id}/tts`);
        const duration = ((Date.now() - ttsStart) / 1000).toFixed(2);

        console.log(`TTS Request completed in ${duration}s`);
        console.log("Audio files:", ttsRes.data.audioFiles);

        // 3. Verify files
        if (ttsRes.data.audioFiles && ttsRes.data.audioFiles.length > 0) {
            const firstFile = ttsRes.data.audioFiles[0];
            // path is /audio/filename.mp3, we need to check local server folder
            const localPath = `/Users/phongalahan/Desktop/Audiobook/server${firstFile}`;

            if (fs.existsSync(localPath)) {
                const stats = fs.statSync(localPath);
                console.log(`✅ File ${firstFile} exists. Size: ${stats.size} bytes`);
                if (stats.size > 1000) {
                    console.log("✅ Size looks reasonable (>1KB). Audio likely generated.");
                } else {
                    console.log("⚠️ File size too small. Error?");
                }
            } else {
                console.log(`❌ File ${firstFile} NOT found locally at ${localPath}`);
            }
        }

    } catch (e: any) {
        console.error("Test Failed:", e.message);
        if (e.response) {
            console.error("Response data:", e.response.data);
        }
    }
}
testAudioGeneration();
