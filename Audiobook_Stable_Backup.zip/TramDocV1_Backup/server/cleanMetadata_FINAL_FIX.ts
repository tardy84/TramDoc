    /**
     * Clean metadata patterns from extracted text
     */
    private cleanMetadata(text: string): string {
    const words = text.split(/\s+/);

    // Try to find title repetition in the first 20 words
    // Pattern: "TITLE [other words] TITLE" (author name may be in between)
    for (let titleLen = 2; titleLen <= 5; titleLen++) {
        const potentialTitle = words.slice(0, titleLen).join(' ').toLowerCase();

        // Search for this title appearing again in next 15 words
        for (let searchPos = titleLen; searchPos <= Math.min(20, words.length - titleLen); searchPos++) {
            const candidate = words.slice(searchPos, searchPos + titleLen).join(' ').toLowerCase();

            if (potentialTitle === candidate && potentialTitle.length > 8) {
                // Found duplicate! Remove everything before the SECOND occurrence
                text = words.slice(searchPos).join(' ');
                console.log(`[cleanMetadata] Removed duplicate title: "${potentialTitle}" at position 0 and ${searchPos}`);
                return text.trim();
            }
        }
    }

    return text.trim();
}
