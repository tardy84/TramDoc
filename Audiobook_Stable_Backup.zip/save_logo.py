import base64
import sys

# The base64 data will be passed as the first argument
# It starts with "data:image/png;base64,"
data_str = sys.argv[1]
if data_str.startswith("data:image/png;base64,"):
    data_str = data_str[len("data:image/png;base64,"):]

image_data = base64.b64decode(data_str)

with open("/Users/phongalahan/Desktop/Audiobook/client/public/logo.png", "wb") as f:
    f.write(image_data)

with open("/Users/phongalahan/Desktop/Audiobook/TramDocV1_Backup/client/public/logo.png", "wb") as f:
    f.write(image_data)

print("Logo updated successfully.")
